﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// SWORD.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SWORD : Window
    {
        private int swordlevel = 0;
        static public int depend = 0;
        static public long money = 1000000;
        static private int count = 0;
        private int num = 0;
        private int Emerald = 0;
        private string[] swordname = { "주먹도끼", "돌창", "간돌칼", "비파형 동검", "청동검", "요령식 동검", "세형동검", "도검", "환도", "예도", "쌍수도", "왜검", "제독검", "월도", "쌍검", "쇠 검", "철 검", "금 검", "에메랄드 검", "다이아몬드 검", "광선검", "마력 검"};
        

        public SWORD()
        {
            InitializeComponent();
            if (count == 0)
            {
                MONEYPUTS.Text = money.ToString();
                depe.Text = depend.ToString();
            }
            else if(count > 0)
            {
                long a = STORE.num;
                int b = STORE.ticket;
                money = a;
                depend = b;
                MONEYPUTS.Text = money.ToString();
                depe.Text = depend.ToString();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            num = swordlevel;
            rem.Visibility = Visibility.Visible;
            if(swordlevel == 0)
            {
                rem.Content = "상점";
            }
            else
            {
                rem.Content = "판매";
            }
            reinmoney.FontSize = 26;
            switch (swordlevel)
            {
                case 0:
                     
                    swordlevel += 1;
                    reinmoney.Text = "강화비용: 300원\n판매가격: 0원";
                    choice.Text = "성공률 100%";
                    break;
                case 1:
                     
                    if (money < 300)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    swordlevel += 1;
                    money -= 300;
                    MONEYPUTS.Text = money.ToString();
                    reinmoney.Text = "강화비용: 500원\n판매가격: 400원";
                    choice.Text = "성공률 100%";
                    break;
                case 2:
                     
                    if (money < 500)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    swordlevel += 1;
                    money -= 500;
                    MONEYPUTS.Text = money.ToString();
                    reinmoney.Text = "강화비용: 500원\n판매가격: 600원";
                    choice.Text = "성공률 95%";
                    break;
                case 3:
                    if (money < 500)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 500;
                    MONEYPUTS.Text = money.ToString();
                    Random ran80 = new Random();
                    int a80 = ran80.Next(0, 100);
                    if (a80 < 95)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 1,000원\n판매가격: 800원";
                        choice.Text = "성공률 95%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "검이 파괴되었습니다";
                        rem.Visibility = Visibility.Hidden;
                        swordlevel = 0;
                        
                    }
                    break;
                case 4:
                    if (money < 1000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 1000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran1 = new Random();
                    int a1 = ran1.Next(0, 100);
                    if (a1 < 95)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 1,500원\n판매가격: 1,600원";
                        choice.Text = "성공률 90%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "검이 파괴되었습니다";
                        rem.Visibility = Visibility.Hidden;
                        swordlevel = 0;
                        
                    }
                    break;
                case 5:
                    if (money < 1500)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 1500;
                    MONEYPUTS.Text = money.ToString();
                    Random ran2 = new Random();
                    int a2 = ran2.Next(0, 100);
                    if (a2 < 90)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 2,000원\n판매가격: 3,500원";
                        choice.Text = "성공률 90%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "검이 파괴되었습니다";
                        rem.Visibility = Visibility.Hidden;
                        swordlevel = 0;
                        
                    }
                    break;
                case 6:
                    if (money < 2000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 2000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran3 = new Random();
                    int a3 = ran3.Next(0, 100);
                    if (a3 < 90)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 2,000원\n판매가격: 6,100원";
                        choice.Text = "성공률 90%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 7:
                    if (money < 2000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 2000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran4 = new Random();
                    int a4 = ran4.Next(0, 100);
                    if (a4 < 90)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 3,000원\n판매가격: 10,000원";
                        choice.Text = "성공률 85%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 8:
                    if (money < 3000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 3000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran5 = new Random();
                    int a5 = ran5.Next(0, 100);
                    if (a5 < 85)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 5,000원\n판매가격: 20,000원";
                        choice.Text = "성공률 80%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 9:
                    if (money < 5000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 5000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran6 = new Random();
                    int a6 = ran6.Next(0, 100);
                    if (a6 < 80)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 10,900원\n판매가격: 35,100원";
                        choice.Text = "성공률 80%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 10:
                    if (money < 10900)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 10900;
                    MONEYPUTS.Text = money.ToString();
                    Random ran7 = new Random();
                    int a7 = ran7.Next(0, 100);
                    if (a7 < 80)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 20,000원\n판매가격: 160,000원";
                        choice.Text = "성공률 75%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 11:
                    if (money < 20000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 20000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran8 = new Random();
                    int a8 = ran8.Next(0, 100);
                    if (a8 < 75)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 35,000원\n판매가격: 350,000원";
                        choice.Text = "성공률 70%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 12:
                    if (money < 35000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 35000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran9 = new Random();
                    int a9 = ran9.Next(0, 100);
                    if (a9 < 70)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 55,000원\n판매가격: 1,000,000원";
                        choice.Text = "성공률 70%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 1개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 13:
                    if (money < 55000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 55000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran10 = new Random();
                    int a10 = ran10.Next(0, 100);
                    if (a10 < 70)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 100,000원\n판매가격: 3,000,000원";
                        choice.Text = "성공률 65%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 2개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 14:
                    if (money < 100000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 100000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran11 = new Random();
                    int a11 = ran11.Next(0, 100);
                    if (a11 < 65)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 180,000원\n판매가격: 7,500,000원";
                        choice.Text = "성공률 60%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 3개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 15:
                    if (money < 180000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 180000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran12 = new Random();
                    int a12 = ran12.Next(0, 100);
                    if (a12 < 60)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 300,000원\n판매가격: 14,200,000원";
                        choice.Text = "성공률 60%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 4개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 16:
                    if (money < 300000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 300000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran13 = new Random();
                    int a13 = ran13.Next(0, 100);
                    if (a13 < 60)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 300,000원\n판매가격: 20,000,000원";
                        choice.Text = "성공률 55%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 7개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 17:
                    if (money < 300000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 300000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran14 = new Random();
                    int a14 = ran14.Next(0, 100);
                    if (a14 < 55)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 500,000원\n판매가격: 30,000,000원";
                        choice.Text = "성공률 50%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 9개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 18:
                    if (money < 500000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 500000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran15 = new Random();
                    int a15 = ran15.Next(0, 100);
                    if (a15 < 50)
                    {
                         
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 800,000원\n판매가격: 47,500,000원";
                        choice.Text = "성공률 50%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 10개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 19:
                    if (money < 800000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 800000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran16 = new Random();
                    int a16 = ran16.Next(0, 100);
                    if (a16 < 50)
                    {
                        box.Visibility = Visibility.Visible;
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 1,500,000원\n판매가격: 68,300,000원";
                        choice.Text = "성공률 45%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 12개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 20:
                    if (money < 1500000)
                    {
                        nomoney.Text = "돈이 부족합니다";
                        break;
                    }
                    money -= 1500000;
                    MONEYPUTS.Text = money.ToString();
                    Random ran17 = new Random();
                    int a17 = ran17.Next(0, 100);
                    if (a17 < 45)
                    {
                        box.Visibility = Visibility.Hidden;
                        swordlevel += 1;
                        reinmoney.Text = "강화비용: 다이아몬드 검 2자루\n판매가격: 101,000,000원";
                        choice.Text = "성공률 40%";
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 15개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 21:
                    if (Emerald < 2)
                    {
                        nomoney.Text = "다이아몬드 검이 부족합니다(보유: "+Emerald+")";
                        break;
                    }
                    Emerald -= 2;
                    Random ran18 = new Random();
                    int a18 = ran18.Next(0, 100);
                    if (a18 < 40)
                    {
                        upgrade.Visibility = Visibility.Hidden;
                        swordlevel += 1;
                        reinmoney.Text = string.Empty;
                        choice.Text = string.Empty;
                    }
                    else
                    {
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/깨진 검.jpeg"));
                        SWORDOUT.Text = "강화에 실패했습니다";
                        reinmoney.FontSize = 19;
                        reinmoney.Text = "방지권을 사용하여 검을 살릴 수 있습니다\n필요한 방지권: 17개";
                        rem.Content = "방지권 사용";
                        swordlevel = 0;
                        
                    }
                    break;
                case 22:
                    break;
            }
            switch (swordlevel)
            {
                case 1:
                    SWORDOUT.Text = "Lv. 1 " + swordname[0];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/주먹도끼.jpg"));
                    break;
                case 2:
                    SWORDOUT.Text = "Lv. 2 " + swordname[1];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/돌창.jpg"));
                    break;
                case 3:
                    SWORDOUT.Text = "Lv. 3 " + swordname[2];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/간돌칼.jpg"));
                    break;
                case 4:
                    SWORDOUT.Text = "Lv. 4 " + swordname[3];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/비파형 동검.jpg"));
                    break;
                case 5:
                    SWORDOUT.Text = "Lv. 5 " + swordname[4];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/청동검.png"));
                    break;
                case 6:
                    SWORDOUT.Text = "Lv. 6 " + swordname[5];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/요령식 동검.jpg"));
                    break;
                case 7:
                    SWORDOUT.Text = "Lv. 7 " + swordname[6];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/세형동검.jpg"));
                    break;
                case 8:
                    SWORDOUT.Text = "Lv. 8 " + swordname[7];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/도검.jpg"));
                    break;
                case 9:
                    SWORDOUT.Text = "Lv. 9 " + swordname[8];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/환도.jpg"));
                    break;
                case 10:
                    SWORDOUT.Text = "Lv. 10 " + swordname[9];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/예도.jpg"));
                    break;
                case 11:
                    SWORDOUT.Text = "Lv. 11 " + swordname[10];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/쌍수도.jpg"));
                    break;
                case 12:
                    SWORDOUT.Text = "Lv. 12 " + swordname[11];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/왜검.jpg"));
                    break;
                case 13:
                    SWORDOUT.Text = "Lv. 13 " + swordname[12];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/제독검.jpg"));
                    break;
                case 14:
                    SWORDOUT.Text = "Lv. 14 " + swordname[13];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/월도.jpg"));
                    break;
                case 15:
                    SWORDOUT.Text = "Lv. 15 " + swordname[14];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/쌍검.jpg"));
                    break;
                case 16:
                    SWORDOUT.Text = "Lv. 16 " + swordname[15];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/쇠 검.jpg"));
                    break;
                case 17:
                    SWORDOUT.Text = "Lv. 17 " + swordname[16];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/철 검.png"));
                    break;
                case 18:
                    SWORDOUT.Text = "Lv. 18 " + swordname[17];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/금 검.png"));
                    break;
                case 19:
                    SWORDOUT.Text = "Lv. 19 " + swordname[18];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/에메랄드 검.jpg"));
                    break;
                case 20:
                    SWORDOUT.Text = "Lv. 20 " + swordname[19];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/다이아몬드 검.png"));
                    break;
                case 21:
                    SWORDOUT.Text = "Lv. 21 " + swordname[20];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/광선검.jpg"));
                    break;
                case 22:
                    SWORDOUT.Text = "Lv. 22 " + swordname[21];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/마력 검.png"));
                    break;
                default:
                    break;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (rem.Content.ToString() == "판매")
            {
                rem.Visibility = Visibility.Hidden;
                num = 0;
                switch (swordlevel)
                {
                    case 2:
                        money += 400;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 3:
                        money += 600;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 4:
                        money += 800;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 5:
                        money += 1600;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 6:
                        money += 3500;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 7:
                        money += 6100;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 8:
                        money += 10000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 9:
                        money += 20000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 10:
                        money += 35100;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 11:
                        money += 160000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 12:
                        money += 350000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 13:
                        money += 1000000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 14:
                        money += 3000000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 15:
                        money += 7500000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 16:
                        money += 14200000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 17:
                        money += 20000000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        choice.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 18:
                        money += 30000000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 19:
                        money += 47500000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 20:
                        money += 68300000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 21:
                        money += 101000000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        break;
                    case 22:
                        money += 160000000;
                        MONEYPUTS.Text = money.ToString();
                        swordlevel = 0;
                        SWORDOUT.Text = string.Empty;
                        reinmoney.Text = string.Empty;
                        choice.Text = string.Empty;
                        imgs.Source = new BitmapImage(new Uri("pack://application:,,,/판매완료.png"));
                        upgrade.Visibility = Visibility.Visible;
                        break;
                }
            }else if(rem.Content.ToString() == "상점")
            {
                count = 1;
                this.Hide();
                STORE frm3 = new STORE();
                frm3.Show();
            }else if(rem.Content.ToString() == "방지권 사용")
            {
                rem.Content = "판매";
                reinmoney.FontSize = 26;
                if (num == 6 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 6;
                    SWORDOUT.Text = "Lv. 6 " + swordname[5];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/요령식 동검.jpg"));
                    reinmoney.Text = "강화비용: 2,000원\n판매가격: 3,500원";
                    choice.Text = "성공률 90%";
                }
                else if (num == 7 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 7;
                    SWORDOUT.Text = "Lv. 7 " + swordname[6];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/세형동검.jpg"));
                    reinmoney.Text = "강화비용: 2,000원\n판매가격: 6,100원";
                    choice.Text = "성공률 90%";
                }
                else if (num == 8 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 8;
                    SWORDOUT.Text = "Lv. 8 " + swordname[7];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/도검.jpg"));
                    reinmoney.Text = "강화비용: 3,000원\n판매가격: 10,000원";
                    choice.Text = "성공률 85%";
                }
                else if (num == 9 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 9;
                    SWORDOUT.Text = "Lv. 9 " + swordname[8];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/환도.jpg"));
                    reinmoney.Text = "강화비용: 5,000원\n판매가격: 20,000원";
                    choice.Text = "성공률 80%";
                }
                else if (num == 10 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 10;
                    SWORDOUT.Text = "Lv. 10 " + swordname[9];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/예도.jpg"));
                    reinmoney.Text = "강화비용: 10,900원\n판매가격: 35,100원";
                    choice.Text = "성공률 80%";
                }
                else if (num == 11 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 11;
                    SWORDOUT.Text = "Lv. 11 " + swordname[10];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/쌍수도.jpg"));
                    reinmoney.Text = "강화비용: 20,000원\n판매가격: 160,000원";
                    choice.Text = "성공률 75%";
                }
                else if (num == 12 && depend > 1)
                {
                    depend -= 1;
                    depe.Text = depend.ToString();
                    swordlevel = 12;
                    SWORDOUT.Text = "Lv. 12 " + swordname[11];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/왜검.jpg"));
                    reinmoney.Text = "강화비용: 35,000원\n판매가격: 350,000원";
                    choice.Text = "성공률 70%";
                }
                else if (num == 13 && depend > 2)
                {
                    depend -= 2;
                    depe.Text = depend.ToString();
                    swordlevel = 13;
                    SWORDOUT.Text = "Lv. 13 " + swordname[12];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/제독검.jpg"));
                    reinmoney.Text = "강화비용: 55,000원\n판매가격: 1,000,000원";
                    choice.Text = "성공률 70%";
                }
                else if (num == 14 && depend > 3)
                {
                    depend -= 3;
                    depe.Text = depend.ToString();
                    swordlevel = 14;
                    SWORDOUT.Text = "Lv. 14 " + swordname[13];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/월도.jpg"));
                    reinmoney.Text = "강화비용: 100,000원\n판매가격: 3,000,000원";
                    choice.Text = "성공률 65%";
                }
                else if (num == 15 && depend > 4)
                {
                    depend -= 4;
                    depe.Text = depend.ToString();
                    swordlevel = 15;
                    SWORDOUT.Text = "Lv. 15 " + swordname[14];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/쌍검.jpg"));
                    reinmoney.Text = "강화비용: 180,000원\n판매가격: 7,500,000원";
                    choice.Text = "성공률 60%";
                }
                else if (num == 16 && depend > 7)
                {
                    depend -= 7;
                    depe.Text = depend.ToString();
                    swordlevel = 16;
                    SWORDOUT.Text = "Lv. 16 " + swordname[15];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/쇠 검.jpg"));
                    reinmoney.Text = "강화비용: 300,000원\n판매가격: 14,200,000원";
                    choice.Text = "성공률 60%";
                }
                else if (num == 17 && depend > 9)
                {
                    depend -= 9;
                    depe.Text = depend.ToString();
                    swordlevel = 17;
                    SWORDOUT.Text = "Lv. 17 " + swordname[16];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/철 검.png"));
                    reinmoney.Text = "강화비용: 300,000원\n판매가격: 20,000,000원";
                    choice.Text = "성공률 55%";
                }
                else if (num == 18 && depend > 10)
                {
                    depend -= 10;
                    depe.Text = depend.ToString();
                    swordlevel = 18;
                    SWORDOUT.Text = "Lv. 18 " + swordname[17];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/금 검.png"));
                    reinmoney.Text = "강화비용: 500,000원\n판매가격: 30,000,000원";
                    choice.Text = "성공률 50%";
                }
                else if (num == 19 && depend > 12)
                {
                    depend -= 12;
                    depe.Text = depend.ToString();
                    swordlevel = 19;
                    SWORDOUT.Text = "Lv. 19 " + swordname[18];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/에메랄드 검.jpg"));
                    reinmoney.Text = "강화비용: 800,000원\n판매가격: 47,500,000원";
                    choice.Text = "성공률 50%";
                }
                else if (num == 20 && depend > 15)
                {
                    depend -= 15;
                    depe.Text = depend.ToString();
                    swordlevel = 20;
                    SWORDOUT.Text = "Lv. 20 " + swordname[19];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/다이아몬드 검.png"));
                    reinmoney.Text = "강화비용: 1,500,000원\n판매가격: 68,300,000원";
                    choice.Text = "성공률 45%";
                }
                else if (num == 21 && depend > 17)
                {
                    depend -= 17;
                    depe.Text = depend.ToString();
                    swordlevel = 21;
                    SWORDOUT.Text = "Lv. 21 " + swordname[20];
                    imgs.Source = new BitmapImage(new Uri("pack://application:,,,/광선검.jpg"));
                    reinmoney.Text = "강화비용: 다이아몬드 검 2자루\n판매가격: 101,000,000원";
                    choice.Text = "성공률 40%";
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Emerald += 1;
            box.Visibility = Visibility.Hidden;
            swordlevel = 1;
            reinmoney.Text = "강화비용: 300원\n판매가격: 0원";
            choice.Text = "성공률 100%";
            SWORDOUT.Text = "Lv. 1 " + swordname[0];
            imgs.Source = new BitmapImage(new Uri("pack://application:,,,/주먹도끼.jpg"));
        }
    }
}


