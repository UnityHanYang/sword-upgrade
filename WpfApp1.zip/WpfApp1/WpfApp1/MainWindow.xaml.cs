﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {   
        public MainWindow()
        {
            InitializeComponent();
        }

        public static List<string> id = new List<string>();
        public static Dictionary< string, string> pw = new Dictionary<string, string>();
        bool idCheck= false;
        bool pwCheck= false;
        private void LOGIN_BU_Click(object sender, RoutedEventArgs e)
        {

            for (int i = 0; i < id.Count; i++)
            {
                if (ID_BOX.Text == id[i])
                {
                    idCheck = true;
                    break;
                }

            }
            for (int i = 0; i < pw.Count; i++)
            {
                if (PASS_BOX.Text == pw[ID_BOX.Text])
                {
                    pwCheck = true;
                    break;
                }

            }
            if (idCheck && pwCheck)
            {
                this.Hide();
                FORM2 frm1 = new FORM2();
                frm1.Owner = this;
                frm1.Show();
            }
            else
            {
                MessageBox.Show("존재하지 않는 계정입니다");
            }
        }

        private void JOIN_BU_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            FORM3 frm2 = new FORM3();
            frm2.Owner = this;
            frm2.Show();
        }
    }
}
