﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// STORE.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class STORE : Window
    {
        static public long num = 0;
        static public int ticket = 0;
       
        public STORE()
        {
            InitializeComponent();
            long a = SWORD.money;
            int b = SWORD.depend;
            num = a;
            ticket = b;
            moneyput2.Text = num.ToString();
            depe.Text = ticket.ToString();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            SWORD frm3 = new SWORD();
            frm3.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (num >= 1000000)
            {
                num -= 1000000;
                moneyput2.Text = num.ToString();
                ticket += 1;
                depe.Text = ticket.ToString();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (num >= 4000000)
            {
                num -= 4000000;
                moneyput2.Text = num.ToString();
                ticket += 5;
                depe.Text = ticket.ToString();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (num >= 8000000)
            {
                num -= 8000000;
                moneyput2.Text = num.ToString();
                ticket += 10;
                depe.Text = ticket.ToString();
            }
        }
    }
}
