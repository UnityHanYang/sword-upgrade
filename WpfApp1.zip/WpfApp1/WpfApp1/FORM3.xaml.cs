﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// FORM3.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class FORM3 : Window
    {
        public FORM3()
        {
            InitializeComponent();
        }
        private void JOIN_BUTTON_Click(object sender, RoutedEventArgs e)
        {
            if (ID2_BOX.Text == "")
            {
                MessageBox.Show("아이디 혹은 비밀번호를 입력하세요", "오류", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            } else if (PASS2_BOX.Text == "")
            {
                MessageBox.Show("비밀번호를 입력하세요", "오류", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            }else if(RETYR2_BOX.Text == "")
            {
                MessageBox.Show("비밀번호를 재입력하세요", "오류", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            }else if(PASS2_BOX.Text != RETYR2_BOX.Text)
            {
                MessageBox.Show("비밀번호가 일치하지 않습니다", "오류", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            }else
            {
                MainWindow.id.Add(ID2_BOX.Text);
                MainWindow.pw.Add(ID2_BOX.Text, PASS2_BOX.Text);
                    MessageBox.Show("회원가입 완료!\n2초 뒤에 로그인 창으로 이동합니다");
                    Thread.Sleep(2000);
                    this.Hide();
                    MainWindow frm3 = new MainWindow();
                    frm3.Owner = this;
                    frm3.Show();
            }
            
            
        }
    }
}
